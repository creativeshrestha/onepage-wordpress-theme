<?php
/**
 * Template Name: Home page
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">

		<div id="fullpage" class="home-page">

			<div class="section" id="section0">
				<div class="container">
					<div class="heading-title" data-0="transform: translateY(-3%);" data-end="transform: translateY(200px);">
							<h1>we believe, you can change the world <br/>
							when you look beyond the obvious<br/>
							and think beyond the ordinary.</h1>
					</div>
				</div>
			</div> <!--/section0 -->

		</div> <!-- /fullpage -->

		<div class="section" id="section2">
			<div class="container">
				<div class="heading-title" data-0="transform: translateY(-3%);" data-end="transform: translateY(200px);">
						<h2>about <span>more about us</span></h2>
						<img src="" alt="" />
						<h3>our aspiration</h3>
						<p>
							the pursuit for perfection, and passion for excellence is what drives us forward. to challenge conventions and the status quo in marketing &amp; communications to create breakthroughs for our clients and success stories for their brands.
						</p>
				</div>
			</div>
		</div> <!--/section0 -->


		</main><!-- #main -->
	</div><!-- #primary -->

<?php
// get_sidebar();
get_footer();
