<?php
/**
 * Template Name: Portfolio page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package alt
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
				$my_work = new WP_Query(array(
					'post_type' => 'work',
				));
			?>

			<?php while ($my_work->have_posts()) : $my_work->the_post(); ?>
				 <h1><?php echo the_title(); ?></h1>
				 <p> <?php echo the_content('description'); ?> </p>
				 <?php //dynamic_sidebar( 'custombanner' ); ?>
			 <?php endwhile; ?> 

		</main><!-- #main -->

	</div><!-- #primary -->

<?php

// get_sidebar();
get_footer();
