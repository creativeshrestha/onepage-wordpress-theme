<?php
/**
 * Template Name: Testimonials page
 *
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
				$my_testimonials = new WP_Query(array(
					'post_type' => 'testimonials', 
				));
			?>

			<?php while ($my_testimonials->have_posts()) : $my_testimonials->the_post(); ?>
				 <h1><?php echo the_title(); ?></h1>
				 <p> <?php echo the_content('description'); ?> </p>
				 <?php //dynamic_sidebar( 'custombanner' ); ?>
			 <?php endwhile; ?>

		</main><!-- #main -->

	</div><!-- #primary -->

<?php

get_footer();
